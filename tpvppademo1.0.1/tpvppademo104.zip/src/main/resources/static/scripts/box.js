$(function() {

	$("#box-button").click(function(){
		$("#box-fixed").addClass("box-fixed-close");
	});

});